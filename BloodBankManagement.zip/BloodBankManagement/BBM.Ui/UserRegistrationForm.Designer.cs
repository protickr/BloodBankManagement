﻿namespace BBM.Ui
{
    partial class userRegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.userRegistrationGrid = new MetroFramework.Controls.MetroGrid();
            this.backButtonRegistrationForm = new MetroFramework.Controls.MetroButton();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.bloodGroupRegistrationForm = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.labeldistrict = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.confirmButtonRegistrationForm = new MetroFramework.Controls.MetroButton();
            this.clearButtonRegistrationForm = new MetroFramework.Controls.MetroButton();
            this.userNameRegistrationForm = new MetroFramework.Controls.MetroTextBox();
            this.emailRegistrationForm = new MetroFramework.Controls.MetroTextBox();
            this.phoneRegistrationForm = new MetroFramework.Controls.MetroTextBox();
            this.ageRegistrationForm = new MetroFramework.Controls.MetroTextBox();
            this.houseNumberRegistrationForm = new MetroFramework.Controls.MetroTextBox();
            this.roadNumberRegistrationForm = new MetroFramework.Controls.MetroTextBox();
            this.subDistrictRegistrationForm = new MetroFramework.Controls.MetroTextBox();
            this.districtRegistrationForm = new MetroFramework.Controls.MetroTextBox();
            this.countryRegistrationForm = new MetroFramework.Controls.MetroTextBox();
            this.zipCodeRegistrationForm = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.passwordUserRegistrationForm = new MetroFramework.Controls.MetroTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.userRegistrationGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // userRegistrationGrid
            // 
            this.userRegistrationGrid.AllowUserToResizeRows = false;
            this.userRegistrationGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.userRegistrationGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.userRegistrationGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.userRegistrationGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.userRegistrationGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.userRegistrationGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.userRegistrationGrid.DefaultCellStyle = dataGridViewCellStyle2;
            this.userRegistrationGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userRegistrationGrid.EnableHeadersVisualStyles = false;
            this.userRegistrationGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.userRegistrationGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.userRegistrationGrid.Location = new System.Drawing.Point(20, 60);
            this.userRegistrationGrid.Name = "userRegistrationGrid";
            this.userRegistrationGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.userRegistrationGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.userRegistrationGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.userRegistrationGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.userRegistrationGrid.Size = new System.Drawing.Size(830, 495);
            this.userRegistrationGrid.TabIndex = 0;
            // 
            // backButtonRegistrationForm
            // 
            this.backButtonRegistrationForm.Location = new System.Drawing.Point(767, 72);
            this.backButtonRegistrationForm.Name = "backButtonRegistrationForm";
            this.backButtonRegistrationForm.Size = new System.Drawing.Size(80, 23);
            this.backButtonRegistrationForm.TabIndex = 1;
            this.backButtonRegistrationForm.Text = "Back";
            this.backButtonRegistrationForm.UseSelectable = true;
            this.backButtonRegistrationForm.Click += new System.EventHandler(this.backButtonRegistrationForm_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(262, 72);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(45, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Name";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(266, 109);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(41, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Email";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(261, 143);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(46, 19);
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Phone";
            // 
            // bloodGroupRegistrationForm
            // 
            this.bloodGroupRegistrationForm.FormattingEnabled = true;
            this.bloodGroupRegistrationForm.ItemHeight = 23;
            this.bloodGroupRegistrationForm.Items.AddRange(new object[] {
            "Select Blood Group",
            "O ( + ve )",
            "O ( - ve )",
            "A ( + ve )",
            "A ( - ve )",
            "B ( + ve )",
            "B ( - ve )",
            "AB ( + ve )",
            "AB ( - ve )"});
            this.bloodGroupRegistrationForm.Location = new System.Drawing.Point(317, 208);
            this.bloodGroupRegistrationForm.Name = "bloodGroupRegistrationForm";
            this.bloodGroupRegistrationForm.Size = new System.Drawing.Size(227, 29);
            this.bloodGroupRegistrationForm.TabIndex = 5;
            this.bloodGroupRegistrationForm.UseSelectable = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(222, 208);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(85, 19);
            this.metroLabel4.TabIndex = 6;
            this.metroLabel4.Text = "Blood Group";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(274, 253);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(33, 19);
            this.metroLabel5.TabIndex = 7;
            this.metroLabel5.Text = "Age";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(209, 292);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(98, 19);
            this.metroLabel6.TabIndex = 8;
            this.metroLabel6.Text = "House Number";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(214, 335);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(93, 19);
            this.metroLabel7.TabIndex = 9;
            this.metroLabel7.Text = "Road Number";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(233, 374);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(74, 19);
            this.metroLabel8.TabIndex = 10;
            this.metroLabel8.Text = "Sub District";
            // 
            // labeldistrict
            // 
            this.labeldistrict.AutoSize = true;
            this.labeldistrict.Location = new System.Drawing.Point(259, 412);
            this.labeldistrict.Name = "labeldistrict";
            this.labeldistrict.Size = new System.Drawing.Size(48, 19);
            this.labeldistrict.TabIndex = 11;
            this.labeldistrict.Text = "District";
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(251, 456);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(56, 19);
            this.metroLabel10.TabIndex = 12;
            this.metroLabel10.Text = "Country";
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(243, 490);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(64, 19);
            this.metroLabel11.TabIndex = 13;
            this.metroLabel11.Text = "Zip Code";
            // 
            // confirmButtonRegistrationForm
            // 
            this.confirmButtonRegistrationForm.Location = new System.Drawing.Point(317, 529);
            this.confirmButtonRegistrationForm.Name = "confirmButtonRegistrationForm";
            this.confirmButtonRegistrationForm.Size = new System.Drawing.Size(103, 23);
            this.confirmButtonRegistrationForm.TabIndex = 14;
            this.confirmButtonRegistrationForm.Text = "Confirm";
            this.confirmButtonRegistrationForm.UseSelectable = true;
            this.confirmButtonRegistrationForm.Click += new System.EventHandler(this.confirmButtonRegistrationForm_Click);
            // 
            // clearButtonRegistrationForm
            // 
            this.clearButtonRegistrationForm.Location = new System.Drawing.Point(434, 529);
            this.clearButtonRegistrationForm.Name = "clearButtonRegistrationForm";
            this.clearButtonRegistrationForm.Size = new System.Drawing.Size(110, 23);
            this.clearButtonRegistrationForm.TabIndex = 15;
            this.clearButtonRegistrationForm.Text = "Clear";
            this.clearButtonRegistrationForm.UseSelectable = true;
            this.clearButtonRegistrationForm.Click += new System.EventHandler(this.clearButtonRegistrationForm_Click);
            // 
            // userNameRegistrationForm
            // 
            // 
            // 
            // 
            this.userNameRegistrationForm.CustomButton.Image = null;
            this.userNameRegistrationForm.CustomButton.Location = new System.Drawing.Point(205, 1);
            this.userNameRegistrationForm.CustomButton.Name = "";
            this.userNameRegistrationForm.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.userNameRegistrationForm.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.userNameRegistrationForm.CustomButton.TabIndex = 1;
            this.userNameRegistrationForm.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.userNameRegistrationForm.CustomButton.UseSelectable = true;
            this.userNameRegistrationForm.CustomButton.Visible = false;
            this.userNameRegistrationForm.Lines = new string[0];
            this.userNameRegistrationForm.Location = new System.Drawing.Point(317, 72);
            this.userNameRegistrationForm.MaxLength = 32767;
            this.userNameRegistrationForm.Name = "userNameRegistrationForm";
            this.userNameRegistrationForm.PasswordChar = '\0';
            this.userNameRegistrationForm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.userNameRegistrationForm.SelectedText = "";
            this.userNameRegistrationForm.SelectionLength = 0;
            this.userNameRegistrationForm.SelectionStart = 0;
            this.userNameRegistrationForm.Size = new System.Drawing.Size(227, 23);
            this.userNameRegistrationForm.TabIndex = 16;
            this.userNameRegistrationForm.UseSelectable = true;
            this.userNameRegistrationForm.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.userNameRegistrationForm.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // emailRegistrationForm
            // 
            // 
            // 
            // 
            this.emailRegistrationForm.CustomButton.Image = null;
            this.emailRegistrationForm.CustomButton.Location = new System.Drawing.Point(205, 1);
            this.emailRegistrationForm.CustomButton.Name = "";
            this.emailRegistrationForm.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.emailRegistrationForm.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.emailRegistrationForm.CustomButton.TabIndex = 1;
            this.emailRegistrationForm.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.emailRegistrationForm.CustomButton.UseSelectable = true;
            this.emailRegistrationForm.CustomButton.Visible = false;
            this.emailRegistrationForm.Lines = new string[0];
            this.emailRegistrationForm.Location = new System.Drawing.Point(317, 109);
            this.emailRegistrationForm.MaxLength = 32767;
            this.emailRegistrationForm.Name = "emailRegistrationForm";
            this.emailRegistrationForm.PasswordChar = '\0';
            this.emailRegistrationForm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.emailRegistrationForm.SelectedText = "";
            this.emailRegistrationForm.SelectionLength = 0;
            this.emailRegistrationForm.SelectionStart = 0;
            this.emailRegistrationForm.Size = new System.Drawing.Size(227, 23);
            this.emailRegistrationForm.TabIndex = 17;
            this.emailRegistrationForm.UseSelectable = true;
            this.emailRegistrationForm.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.emailRegistrationForm.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // phoneRegistrationForm
            // 
            // 
            // 
            // 
            this.phoneRegistrationForm.CustomButton.Image = null;
            this.phoneRegistrationForm.CustomButton.Location = new System.Drawing.Point(205, 1);
            this.phoneRegistrationForm.CustomButton.Name = "";
            this.phoneRegistrationForm.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.phoneRegistrationForm.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.phoneRegistrationForm.CustomButton.TabIndex = 1;
            this.phoneRegistrationForm.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.phoneRegistrationForm.CustomButton.UseSelectable = true;
            this.phoneRegistrationForm.CustomButton.Visible = false;
            this.phoneRegistrationForm.Lines = new string[0];
            this.phoneRegistrationForm.Location = new System.Drawing.Point(317, 143);
            this.phoneRegistrationForm.MaxLength = 32767;
            this.phoneRegistrationForm.Name = "phoneRegistrationForm";
            this.phoneRegistrationForm.PasswordChar = '\0';
            this.phoneRegistrationForm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.phoneRegistrationForm.SelectedText = "";
            this.phoneRegistrationForm.SelectionLength = 0;
            this.phoneRegistrationForm.SelectionStart = 0;
            this.phoneRegistrationForm.Size = new System.Drawing.Size(227, 23);
            this.phoneRegistrationForm.TabIndex = 18;
            this.phoneRegistrationForm.UseSelectable = true;
            this.phoneRegistrationForm.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.phoneRegistrationForm.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // ageRegistrationForm
            // 
            // 
            // 
            // 
            this.ageRegistrationForm.CustomButton.Image = null;
            this.ageRegistrationForm.CustomButton.Location = new System.Drawing.Point(205, 1);
            this.ageRegistrationForm.CustomButton.Name = "";
            this.ageRegistrationForm.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.ageRegistrationForm.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.ageRegistrationForm.CustomButton.TabIndex = 1;
            this.ageRegistrationForm.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.ageRegistrationForm.CustomButton.UseSelectable = true;
            this.ageRegistrationForm.CustomButton.Visible = false;
            this.ageRegistrationForm.Lines = new string[0];
            this.ageRegistrationForm.Location = new System.Drawing.Point(317, 253);
            this.ageRegistrationForm.MaxLength = 32767;
            this.ageRegistrationForm.Name = "ageRegistrationForm";
            this.ageRegistrationForm.PasswordChar = '\0';
            this.ageRegistrationForm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.ageRegistrationForm.SelectedText = "";
            this.ageRegistrationForm.SelectionLength = 0;
            this.ageRegistrationForm.SelectionStart = 0;
            this.ageRegistrationForm.Size = new System.Drawing.Size(227, 23);
            this.ageRegistrationForm.TabIndex = 19;
            this.ageRegistrationForm.UseSelectable = true;
            this.ageRegistrationForm.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.ageRegistrationForm.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // houseNumberRegistrationForm
            // 
            // 
            // 
            // 
            this.houseNumberRegistrationForm.CustomButton.Image = null;
            this.houseNumberRegistrationForm.CustomButton.Location = new System.Drawing.Point(205, 1);
            this.houseNumberRegistrationForm.CustomButton.Name = "";
            this.houseNumberRegistrationForm.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.houseNumberRegistrationForm.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.houseNumberRegistrationForm.CustomButton.TabIndex = 1;
            this.houseNumberRegistrationForm.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.houseNumberRegistrationForm.CustomButton.UseSelectable = true;
            this.houseNumberRegistrationForm.CustomButton.Visible = false;
            this.houseNumberRegistrationForm.Lines = new string[0];
            this.houseNumberRegistrationForm.Location = new System.Drawing.Point(317, 292);
            this.houseNumberRegistrationForm.MaxLength = 32767;
            this.houseNumberRegistrationForm.Name = "houseNumberRegistrationForm";
            this.houseNumberRegistrationForm.PasswordChar = '\0';
            this.houseNumberRegistrationForm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.houseNumberRegistrationForm.SelectedText = "";
            this.houseNumberRegistrationForm.SelectionLength = 0;
            this.houseNumberRegistrationForm.SelectionStart = 0;
            this.houseNumberRegistrationForm.Size = new System.Drawing.Size(227, 23);
            this.houseNumberRegistrationForm.TabIndex = 20;
            this.houseNumberRegistrationForm.UseSelectable = true;
            this.houseNumberRegistrationForm.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.houseNumberRegistrationForm.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // roadNumberRegistrationForm
            // 
            // 
            // 
            // 
            this.roadNumberRegistrationForm.CustomButton.Image = null;
            this.roadNumberRegistrationForm.CustomButton.Location = new System.Drawing.Point(205, 1);
            this.roadNumberRegistrationForm.CustomButton.Name = "";
            this.roadNumberRegistrationForm.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.roadNumberRegistrationForm.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.roadNumberRegistrationForm.CustomButton.TabIndex = 1;
            this.roadNumberRegistrationForm.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.roadNumberRegistrationForm.CustomButton.UseSelectable = true;
            this.roadNumberRegistrationForm.CustomButton.Visible = false;
            this.roadNumberRegistrationForm.Lines = new string[0];
            this.roadNumberRegistrationForm.Location = new System.Drawing.Point(317, 335);
            this.roadNumberRegistrationForm.MaxLength = 32767;
            this.roadNumberRegistrationForm.Name = "roadNumberRegistrationForm";
            this.roadNumberRegistrationForm.PasswordChar = '\0';
            this.roadNumberRegistrationForm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.roadNumberRegistrationForm.SelectedText = "";
            this.roadNumberRegistrationForm.SelectionLength = 0;
            this.roadNumberRegistrationForm.SelectionStart = 0;
            this.roadNumberRegistrationForm.Size = new System.Drawing.Size(227, 23);
            this.roadNumberRegistrationForm.TabIndex = 21;
            this.roadNumberRegistrationForm.UseSelectable = true;
            this.roadNumberRegistrationForm.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.roadNumberRegistrationForm.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // subDistrictRegistrationForm
            // 
            // 
            // 
            // 
            this.subDistrictRegistrationForm.CustomButton.Image = null;
            this.subDistrictRegistrationForm.CustomButton.Location = new System.Drawing.Point(205, 1);
            this.subDistrictRegistrationForm.CustomButton.Name = "";
            this.subDistrictRegistrationForm.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.subDistrictRegistrationForm.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.subDistrictRegistrationForm.CustomButton.TabIndex = 1;
            this.subDistrictRegistrationForm.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.subDistrictRegistrationForm.CustomButton.UseSelectable = true;
            this.subDistrictRegistrationForm.CustomButton.Visible = false;
            this.subDistrictRegistrationForm.Lines = new string[0];
            this.subDistrictRegistrationForm.Location = new System.Drawing.Point(317, 374);
            this.subDistrictRegistrationForm.MaxLength = 32767;
            this.subDistrictRegistrationForm.Name = "subDistrictRegistrationForm";
            this.subDistrictRegistrationForm.PasswordChar = '\0';
            this.subDistrictRegistrationForm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.subDistrictRegistrationForm.SelectedText = "";
            this.subDistrictRegistrationForm.SelectionLength = 0;
            this.subDistrictRegistrationForm.SelectionStart = 0;
            this.subDistrictRegistrationForm.Size = new System.Drawing.Size(227, 23);
            this.subDistrictRegistrationForm.TabIndex = 22;
            this.subDistrictRegistrationForm.UseSelectable = true;
            this.subDistrictRegistrationForm.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.subDistrictRegistrationForm.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // districtRegistrationForm
            // 
            // 
            // 
            // 
            this.districtRegistrationForm.CustomButton.Image = null;
            this.districtRegistrationForm.CustomButton.Location = new System.Drawing.Point(205, 1);
            this.districtRegistrationForm.CustomButton.Name = "";
            this.districtRegistrationForm.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.districtRegistrationForm.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.districtRegistrationForm.CustomButton.TabIndex = 1;
            this.districtRegistrationForm.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.districtRegistrationForm.CustomButton.UseSelectable = true;
            this.districtRegistrationForm.CustomButton.Visible = false;
            this.districtRegistrationForm.Lines = new string[0];
            this.districtRegistrationForm.Location = new System.Drawing.Point(317, 412);
            this.districtRegistrationForm.MaxLength = 32767;
            this.districtRegistrationForm.Name = "districtRegistrationForm";
            this.districtRegistrationForm.PasswordChar = '\0';
            this.districtRegistrationForm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.districtRegistrationForm.SelectedText = "";
            this.districtRegistrationForm.SelectionLength = 0;
            this.districtRegistrationForm.SelectionStart = 0;
            this.districtRegistrationForm.Size = new System.Drawing.Size(227, 23);
            this.districtRegistrationForm.TabIndex = 23;
            this.districtRegistrationForm.UseSelectable = true;
            this.districtRegistrationForm.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.districtRegistrationForm.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // countryRegistrationForm
            // 
            // 
            // 
            // 
            this.countryRegistrationForm.CustomButton.Image = null;
            this.countryRegistrationForm.CustomButton.Location = new System.Drawing.Point(205, 1);
            this.countryRegistrationForm.CustomButton.Name = "";
            this.countryRegistrationForm.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.countryRegistrationForm.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.countryRegistrationForm.CustomButton.TabIndex = 1;
            this.countryRegistrationForm.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.countryRegistrationForm.CustomButton.UseSelectable = true;
            this.countryRegistrationForm.CustomButton.Visible = false;
            this.countryRegistrationForm.Lines = new string[0];
            this.countryRegistrationForm.Location = new System.Drawing.Point(317, 452);
            this.countryRegistrationForm.MaxLength = 32767;
            this.countryRegistrationForm.Name = "countryRegistrationForm";
            this.countryRegistrationForm.PasswordChar = '\0';
            this.countryRegistrationForm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.countryRegistrationForm.SelectedText = "";
            this.countryRegistrationForm.SelectionLength = 0;
            this.countryRegistrationForm.SelectionStart = 0;
            this.countryRegistrationForm.Size = new System.Drawing.Size(227, 23);
            this.countryRegistrationForm.TabIndex = 24;
            this.countryRegistrationForm.UseSelectable = true;
            this.countryRegistrationForm.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.countryRegistrationForm.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // zipCodeRegistrationForm
            // 
            // 
            // 
            // 
            this.zipCodeRegistrationForm.CustomButton.Image = null;
            this.zipCodeRegistrationForm.CustomButton.Location = new System.Drawing.Point(205, 1);
            this.zipCodeRegistrationForm.CustomButton.Name = "";
            this.zipCodeRegistrationForm.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.zipCodeRegistrationForm.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.zipCodeRegistrationForm.CustomButton.TabIndex = 1;
            this.zipCodeRegistrationForm.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.zipCodeRegistrationForm.CustomButton.UseSelectable = true;
            this.zipCodeRegistrationForm.CustomButton.Visible = false;
            this.zipCodeRegistrationForm.Lines = new string[0];
            this.zipCodeRegistrationForm.Location = new System.Drawing.Point(317, 490);
            this.zipCodeRegistrationForm.MaxLength = 32767;
            this.zipCodeRegistrationForm.Name = "zipCodeRegistrationForm";
            this.zipCodeRegistrationForm.PasswordChar = '\0';
            this.zipCodeRegistrationForm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.zipCodeRegistrationForm.SelectedText = "";
            this.zipCodeRegistrationForm.SelectionLength = 0;
            this.zipCodeRegistrationForm.SelectionStart = 0;
            this.zipCodeRegistrationForm.Size = new System.Drawing.Size(227, 23);
            this.zipCodeRegistrationForm.TabIndex = 25;
            this.zipCodeRegistrationForm.UseSelectable = true;
            this.zipCodeRegistrationForm.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.zipCodeRegistrationForm.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(244, 176);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(63, 19);
            this.metroLabel9.TabIndex = 26;
            this.metroLabel9.Text = "Password";
            // 
            // passwordUserRegistrationForm
            // 
            // 
            // 
            // 
            this.passwordUserRegistrationForm.CustomButton.Image = null;
            this.passwordUserRegistrationForm.CustomButton.Location = new System.Drawing.Point(205, 1);
            this.passwordUserRegistrationForm.CustomButton.Name = "";
            this.passwordUserRegistrationForm.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.passwordUserRegistrationForm.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.passwordUserRegistrationForm.CustomButton.TabIndex = 1;
            this.passwordUserRegistrationForm.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.passwordUserRegistrationForm.CustomButton.UseSelectable = true;
            this.passwordUserRegistrationForm.CustomButton.Visible = false;
            this.passwordUserRegistrationForm.Lines = new string[0];
            this.passwordUserRegistrationForm.Location = new System.Drawing.Point(317, 176);
            this.passwordUserRegistrationForm.MaxLength = 32767;
            this.passwordUserRegistrationForm.Name = "passwordUserRegistrationForm";
            this.passwordUserRegistrationForm.PasswordChar = '●';
            this.passwordUserRegistrationForm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.passwordUserRegistrationForm.SelectedText = "";
            this.passwordUserRegistrationForm.SelectionLength = 0;
            this.passwordUserRegistrationForm.SelectionStart = 0;
            this.passwordUserRegistrationForm.Size = new System.Drawing.Size(227, 23);
            this.passwordUserRegistrationForm.TabIndex = 27;
            this.passwordUserRegistrationForm.UseSelectable = true;
            this.passwordUserRegistrationForm.UseSystemPasswordChar = true;
            this.passwordUserRegistrationForm.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.passwordUserRegistrationForm.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // userRegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(870, 575);
            this.Controls.Add(this.passwordUserRegistrationForm);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.zipCodeRegistrationForm);
            this.Controls.Add(this.countryRegistrationForm);
            this.Controls.Add(this.districtRegistrationForm);
            this.Controls.Add(this.subDistrictRegistrationForm);
            this.Controls.Add(this.roadNumberRegistrationForm);
            this.Controls.Add(this.houseNumberRegistrationForm);
            this.Controls.Add(this.ageRegistrationForm);
            this.Controls.Add(this.phoneRegistrationForm);
            this.Controls.Add(this.emailRegistrationForm);
            this.Controls.Add(this.userNameRegistrationForm);
            this.Controls.Add(this.clearButtonRegistrationForm);
            this.Controls.Add(this.confirmButtonRegistrationForm);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.labeldistrict);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.bloodGroupRegistrationForm);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.backButtonRegistrationForm);
            this.Controls.Add(this.userRegistrationGrid);
            this.Name = "userRegistrationForm";
            this.Text = "Enter Registration Details";
            this.Load += new System.EventHandler(this.UserRegistrationForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.userRegistrationGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroGrid userRegistrationGrid;
        private MetroFramework.Controls.MetroButton backButtonRegistrationForm;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroComboBox bloodGroupRegistrationForm;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel labeldistrict;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroButton confirmButtonRegistrationForm;
        private MetroFramework.Controls.MetroButton clearButtonRegistrationForm;
        private MetroFramework.Controls.MetroTextBox userNameRegistrationForm;
        private MetroFramework.Controls.MetroTextBox emailRegistrationForm;
        private MetroFramework.Controls.MetroTextBox phoneRegistrationForm;
        private MetroFramework.Controls.MetroTextBox ageRegistrationForm;
        private MetroFramework.Controls.MetroTextBox houseNumberRegistrationForm;
        private MetroFramework.Controls.MetroTextBox roadNumberRegistrationForm;
        private MetroFramework.Controls.MetroTextBox subDistrictRegistrationForm;
        private MetroFramework.Controls.MetroTextBox districtRegistrationForm;
        private MetroFramework.Controls.MetroTextBox countryRegistrationForm;
        private MetroFramework.Controls.MetroTextBox zipCodeRegistrationForm;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroTextBox passwordUserRegistrationForm;
    }
}